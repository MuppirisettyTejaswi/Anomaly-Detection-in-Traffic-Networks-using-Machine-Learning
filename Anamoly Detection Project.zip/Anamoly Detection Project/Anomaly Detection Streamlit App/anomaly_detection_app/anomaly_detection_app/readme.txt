Network Anomaly Detection App
----------------------------

This is an interactive web application for detecting anomalies in network traffic using Machine Learning. Built with Streamlit, it uses the Isolation Forest algorithm trained on the KDD Cup 1999 dataset.

Technologies:
-------------
Python
Streamlit	
Scikit-learn	
Pandas & NumPy	
Plotly & Seaborn	
Matplotlib

View Live: https://network-anomaly-app-c3tbeyyqqfwmnoi5efsxvj.streamlit.app

You can:

- Visualize and navigate the dataset
- Make predictions with user input
- Upload your network data (CSV)
- View performance metrics such as ROC and PR curves

Features 
--------
 Interactive Dashboard – Sleek UI to keep track of network traffic anomalies.
 Upload your own CSV files – Try out the model against  custom data.
 Visualizations – ROC, PR curves, pie charts, histograms, and PCA plots.
 Real-Time Prediction – Input network parameters and receive immediate feedback.
 Anomaly Score Gauge – Get a visual indication of how risky your data point is.
 Top Anomalies Table – View most suspicious traffic patterns.

  # To Navigate  Project Directory:

  cd network-anomaly-detection

  # Create a Virtual Environment:

  python -m venv venv

  # To Activate it:

  venv\Scripts\activate

  # To install required libraries

  pip install streamlit pandas numpy scikit-learn plotly seaborn matplotlib

  # To Run the Streamlit App

  streamlit run app.py

   This  app will open in your browser at:

         http://localhost:8501

  To Access  App Online:
    
    https://network-anomaly-app-c3tbeyyqqfwmnoi5efsxvj.streamlit.app





