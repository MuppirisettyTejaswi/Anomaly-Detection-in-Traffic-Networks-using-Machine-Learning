Network Anomaly Detection App


 About This Project:
----------------------
This is a simple  effective web application built using Django that detects network anomalies based on user input. 
It uses a pre-trained Isolation Forest model to classify whether the given network traffic input is normal or anomalous.

 Technologies Used:
-----------------------
- Python 
- Django for web backend
- HTML, CSS for frontend
-Joblib for model loading
- Pre-trained machine learning model (Isolation Forest from scikit-learn)

 Python Libraries Installed:
------------------------------

pip install django
pip install numpy
pip install scikit-learn
pip install joblib


 Project Structure:
---------------------
network_anomaly/
│
├── anomaly_project/ # Main Django project
│ ├── settings.py
│ ├── urls.py
│ └── ...
│
├── detector/ # App where ML logic lives
│ ├── views.py
│ ├── templates/
│ ├── static/
│ └── model.pkl # Pre-trained Isolation Forest model
│
├── static/ # Global static files (style.css)
└── manage.py


Django Setup Commands:
--------------
# Start the Django project
django-admin startproject anomaly_project

# Move into the project directory
cd anomaly_project

# Create the app
python manage.py startapp detector

#Collect all static files  into one folder:
python manage.py collectstatic

To Run the Project:
---------------
python manage.py runserver   # To Run the Django server

Then open your browser and go to:

 http://127.0.0.1:8000

 # 5 Input Features Used
 ---------------------
This anomaly detection system takes five key features as input from the user:

Duration – How long the network connection lasted. Longer or very short durations can sometimes signal abnormal behavior.

Src Bytes – Number of bytes sent from the source (client). Extremely large or small numbers may hint at suspicious data flow.

Dst Bytes – Number of bytes sent to the destination (server). Abnormally high or zero bytes may be a red flag.

Count – Number of connections to the same host in a short window. A burst of requests can be an attack indicator.

Srv Count – Number of connections to the same service. Repeated hits to one service may mean scanning or probing.

These features were selected based on their strong influence on identifying abnormal network traffic patterns using Isolation Forest

# Project Output
--------------
Once the user inputs the values and submits the form, the model predicts whether the connection is:

Normal ✅

Anomaly ❌

It also shows a score for how confident the model is.



Folder/File Summary:
--------------------

- manage.py             → Django project manager
- anomaly_project/      → Main Django project folder
- detector/             → app folder contains views, models, templates
  - views.py             → Where predictions happen
  - urls.py              → Routes HTTP requests
  - templates/           → Contains  HTML files (like home.html)
  - static/              → Place style.css and other static assets here.
- staticfiles/           → Auto-generated after running `collectstatic`

