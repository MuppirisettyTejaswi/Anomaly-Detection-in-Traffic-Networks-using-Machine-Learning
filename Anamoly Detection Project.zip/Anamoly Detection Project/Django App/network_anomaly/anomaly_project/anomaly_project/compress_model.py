import joblib
import os

base_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'detector')

model_path = os.path.join(base_path, 'isolation_model.pkl')
model = joblib.load(model_path)
joblib.dump(model, model_path, compress=3)
print(" Compressed isolation_model.pkl")


scaler_path = os.path.join(base_path, 'scaler.pkl')
scaler = joblib.load(scaler_path)
joblib.dump(scaler, scaler_path, compress=3)
print(" Compressed scaler.pkl")

