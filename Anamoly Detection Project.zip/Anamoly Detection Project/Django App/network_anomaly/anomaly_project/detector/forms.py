from django import forms

class AnomalyInputForm(forms.Form):
    feature_0 = forms.FloatField(label='Duration')
    feature_4 = forms.FloatField(label='Src Bytes')
    feature_5 = forms.FloatField(label='Dst Bytes')
    feature_22 = forms.FloatField(label='Count')
    feature_23 = forms.FloatField(label='Srv Count')
