from django.shortcuts import render
from .forms import AnomalyInputForm
import numpy as np
import joblib
import os


try:
    model = joblib.load(os.path.join(os.path.dirname(__file__), 'isolation_model.pkl'))
    print("✅ Model loaded successfully")
except Exception as e:
    print("❌ Failed to load model:", e)
    model = None

try:
    scaler = joblib.load(os.path.join(os.path.dirname(__file__), 'scaler.pkl'))
    print("✅ Scaler loaded successfully")
except Exception as e:
    print("❌ Failed to load scaler:", e)
    scaler = None


THRESHOLD = 0.01  

def detect_anomaly(request):
    result = None
    score = None

    if request.method == 'POST':
        form = AnomalyInputForm(request.POST)
        if form.is_valid() and model is not None and scaler is not None:
            
            user_input = list(form.cleaned_data.values())
            X = np.array([user_input])
            X_scaled = scaler.transform(X)

            
            score = model.decision_function(X_scaled)[0]
            result = "Anomaly" if score < THRESHOLD else "Normal"

            
            print(" Raw input:", user_input)
            print(" Scaled input:", X_scaled)
            print(f" Score: {score:.4f}")
            print(f" Threshold: {THRESHOLD}")
            print(f" Prediction: {result}")

    else:
        form = AnomalyInputForm()

    
    context = {
        'form': form,
        'result': result,
        'score': score,
        'accuracy': 97.2  
    }

    return render(request, 'detector/home.html', context)
